import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by solovevs on 12-Apr-16.
 */
public class KdTree {
  private class Node {
    private Point2D val;
    private RectHV rect;
    private Node right;
    private Node left;

    public Node(Point2D current, double xmin, double ymin, double xmax, double ymax) {
      val = current;
      rect = new RectHV(xmin, ymin, xmax, ymax);
    }


  }

  private Node root;
  private int size = 0;

  public KdTree() {

  }                          // construct an empty set of points

  public boolean isEmpty() {
    return root == null;
  }                      // is the set empty?

  public int size() {
    return size;
  }                    // number of points in the set

  public void insert(Point2D p) {
    if (p == null) {
      throw new NullPointerException();
    }
    if (root == null) {
      root = new Node(p, 0, 0, 1, 1);
      size++;
    } else {
      findAndInsert(root, p, true);
    }

  }              // add the point to the set (if it is not already in the set)


  private void findAndInsert(Node parent, Point2D p, boolean compareX) {
    if (parent.val.equals(p)) {
      return;
    }
    if (compareX) {
      if (p.x() < parent.val.x()) {
        if (parent.left == null) {
          parent.left = new Node(p, parent.rect.xmin(), parent.rect.ymin(), parent.val.x(), parent.rect.ymax());
          size++;
        } else {
          findAndInsert(parent.left, p, false);
        }

      } else {
        if (parent.right == null) {
          parent.right = new Node(p, parent.val.x(), parent.rect.ymin(), parent.rect.xmax(), parent.rect.ymax());
          size++;
        } else {
          findAndInsert(parent.right, p, false);
        }
      }
    } else {
      if (p.y() < parent.val.y()) {
        if (parent.left == null) {
          parent.left = new Node(p, parent.rect.xmin(), parent.rect.ymin(), parent.rect.xmax(), parent.val.y());
          size++;
        } else {
          findAndInsert(parent.left, p, true);
        }

      } else {
        if (parent.right == null) {
          parent.right = new Node(p, parent.rect.xmin(), parent.val.y(), parent.rect.xmax(), parent.rect.ymax());
          size++;
        } else {
          findAndInsert(parent.right, p, true);
        }
      }
    }
  }

  public boolean contains(Point2D p) {
    if (p == null) {
      throw new NullPointerException();
    }
    if (root == null) {
      return false;
    } else {
      return find(root, p, true);
    }

  }

  private boolean find(Node parent, Point2D p, boolean compareX) {
    if (parent.val.equals(p)) {
      return true;
    }
    if (compareX) {
      if (p.x() < parent.val.x()) {
        if (parent.left == null) {
          return false;
        } else {
          return find(parent.left, p, false);
        }

      } else {
        if (parent.right == null) {
          return false;
        } else {
          return find(parent.right, p, false);
        }
      }
    } else {
      if (p.y() < parent.val.y()) {
        if (parent.left == null) {
          return false;
        } else {
          return find(parent.left, p, true);
        }

      } else {
        if (parent.right == null) {
          return false;
        } else {
          return find(parent.right, p, true);
        }
      }
    }
//    return false;
  }

  public void draw() {
    if (root != null) {
      drawPoints(root);
    }
  }          // draw all points to standard draw

  private void drawPoints(Node n) {
    n.val.draw();
    n.rect.draw();
    if (n.left != null) {
      drawPoints(n.left);
    }
    if (n.right != null) {
      drawPoints(n.right);
    }
  }

  private void findRange(RectHV rect, Node n, List<Point2D> s, boolean compareX) {
    Point2D p = n.val;

    if (rect.xmin() <= p.x() && rect.xmax() >= p.x()) {
      if (rect.ymin() <= p.y() && rect.ymax() >= p.y()) {
        s.add(p);
      }
    }
    if (compareX) {
      if (rect.xmin() <= p.x() && n.left != null) {
        findRange(rect, n.left, s, false);
      }
      if (rect.xmax() >= p.x() && n.right != null) {
        findRange(rect, n.right, s, false);
      }
    } else {
      if (rect.ymin() <= p.y() && n.left != null) {
        findRange(rect, n.left, s, true);
      }
      if (rect.ymax() >= p.y() && n.right != null) {
        findRange(rect, n.right, s, true);
      }
    }

  }

  public Iterable<Point2D> range(RectHV rect) {
    if (rect == null) {
      throw new NullPointerException();
    }
    List<Point2D> list = new ArrayList<>();
    if (root != null) {
      findRange(rect, root, list, true);
    }
    return list;
  }

  // all points that are inside the rectangle
  public Point2D nearest(Point2D p) {
    if (p == null) {
      throw new NullPointerException();
    }
    double dist = Double.MAX_VALUE;
    Point2D nearestP = null;

    if (root != null) {
      nearestP = near2(root, p, true, dist, null);
    }
    return nearestP;
  }      // a nearest neighbor in the set to point p; null if the set is empty

  private Point2D near2(Node n, Point2D p, boolean compareX, double oldDistance, Point2D oldPoint) {

//  double dictForComparing=dist;
    Point2D pointN = n.val;
    double dist = pointN.distanceTo(p);
    Point2D pointNew = null;

    if (dist < oldDistance) {
      pointNew = pointN;
    } else {
      dist = oldDistance;
      pointNew = oldPoint;
    }
    if (compareX) {
      if (p.x() < pointN.x() && n.left != null) {
        pointNew = near2(n.left, p, false, dist, pointNew);
        dist = pointNew.distanceTo(p);
        if (n.right != null && dist >= n.right.rect.distanceTo(p)) {
          pointNew = near2(n.right, p, false, dist, pointNew);
        }

      } else if (n.right != null) {
        pointNew = near2(n.right, p, false, dist, pointNew);
        dist = pointNew.distanceTo(p);
        if (n.left != null && dist >= n.left.rect.distanceTo(p)) {
          pointNew = near2(n.left, p, false, dist, pointNew);
        }
      }
    } else {
      if (p.y() < pointN.y() && n.left != null) {
        pointNew = near2(n.left, p, true, dist, pointNew);
        dist = pointNew.distanceTo(p);
        if (n.right != null && dist >= n.right.rect.distanceTo(p)) {
          pointNew = near2(n.right, p, true, dist, pointNew);
        }
      } else if (n.right != null) {
        pointNew = near2(n.right, p, true, dist, pointNew);
        dist = pointNew.distanceTo(p);
        if (n.left != null && dist >= n.left.rect.distanceTo(p)) {
          pointNew = near2(n.left, p, true, dist, pointNew);
        }
      }
    }
    return pointNew;
  }

  public static void main(String[] args) {
    String filename = args[0];
    In in = new In(filename);

    PointSET brute = new PointSET();
    KdTree kdtree = new KdTree();
    while (!in.isEmpty()) {
      double x = in.readDouble();
      double y = in.readDouble();
      Point2D p = new Point2D(x, y);
      kdtree.insert(p);
      brute.insert(p);
    }

    System.out.println(kdtree.contains(new Point2D(0.5, 1)));
    System.out.println(kdtree.size());
    kdtree.insert(new Point2D(0.5, 1));
    System.out.println(kdtree.size());
  }
}
