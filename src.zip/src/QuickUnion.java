import java.util.Arrays;

/**
 * Created by solovevs on 04-Feb-16.
 */
public class QuickUnion implements Connection{
  int size;
  int[] arr;
  int[] sz;

  public QuickUnion(int size) {
    this.size = size;
    this.arr = new int[size];
    this.sz = new int[size];
    for (int i = 0; i < size; i++) {
      arr[i] = i;
      sz[i] = 1;
    }
  }

  public boolean connected(int p, int q) {
    return root(p) == root(q);
  }

  public int root(int p) {
    while (p != arr[p]) {
      p = arr[p];
    }
    return p;
  }

  public void union(int p, int q) {
    int i = root(p);
    int j = root(q);
    if (i == j) {
      return;
    } else if(sz[j] > sz[i]) {
      arr[i] = j;
      sz[j] += sz[i];
    }else{
      arr[j] = i;
      sz[i] += sz[j];
    }

  }

  public void printArr() {
    System.out.print("-");
    for (int i = 0; i < size; i++) {
      System.out.print(i + " ");
    }
    System.out.print("-");
    System.out.println("\n" + Arrays.toString(arr).replace(",", ""));
  }
}
