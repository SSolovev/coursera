import java.util.Arrays;


public class QuickFind implements Connection{
  int size;
  int[] arr;

  public QuickFind(int size) {
    this.size = size;
    this.arr = new int[size];
    for (int i = 0; i < size; i++) {
      arr[i] = i;
    }
  }


  public void union(int a, int b) {
    int ai =arr[a];
    int bi =arr[b];
    if (bi != ai) {
      for (int i = 0; i < size; i++) {
        if (arr[i] == ai) {
          arr[i] = bi;
        }
      }
    }

  }

  @Override
  public boolean connected(int p, int q) {
    return arr[p] == arr[q];
  }

  @Override
  public int root(int p) {
    return 0;
  }



  public void printArr() {
    System.out.print("-");
    for (int i = 0; i < size; i++) {
      System.out.print(i+" ");
    }
    System.out.print("-");
    System.out.println("\n"+Arrays.toString(arr).replace(",",""));
  }
}
