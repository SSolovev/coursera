package week.three;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FastCollinearPoints {
  private int numberOfSegments = 0;
  private List<LineSegment> lineArr = new ArrayList<>();


  public FastCollinearPoints(Point[] points) {
    if (points == null) {
      throw new NullPointerException();
    }
//        Arrays.sort(points);
//    Arrays.sort(points, points[0].slopeOrder());
    Point[] copyPoints = Arrays.copyOf(points,points.length);

    for (int i = 0; i < points.length - 3; i++) {

      if (points[i] == null) {
        throw new NullPointerException();
      }
      Arrays.sort(points, copyPoints[i].slopeOrder());

      for (int j = 1; j < points.length-2; j++) {
        if (points[j].slopeTo(points[j + 1]) == Double.NEGATIVE_INFINITY) {
          throw new IllegalArgumentException();
        }
        double d1 = points[0].slopeTo(points[j]);
        int amountOfSegments = 1;
        double d2 ;
        int ind=j;
        do{
          amountOfSegments++;
          ind++;
          d2=points[0].slopeTo(points[ind]);
        }while(d1==d2 && ind < points.length-1);

        if(amountOfSegments>3){

          if(d1==d2){ Arrays.sort(points,0,ind+1);
            lineArr.add(new LineSegment(points[0], points[ind]));
          }else{ Arrays.sort(points,0,ind);
            lineArr.add(new LineSegment(points[0], points[ind - 1]));
          }

          numberOfSegments++;
          break;
        }

      }

    }
  }// finds all line segments containing 4 or more points

  public int numberOfSegments() {
    return numberOfSegments;
  }    // the number of line segments

  public LineSegment[] segments() {
    return lineArr.toArray(new LineSegment[0]);
  }  // the line segments
}