

public interface Connection {
  public boolean connected(int p, int q) ;

  public int root(int p) ;

  public void union(int p, int q) ;

  public void printArr();
}
